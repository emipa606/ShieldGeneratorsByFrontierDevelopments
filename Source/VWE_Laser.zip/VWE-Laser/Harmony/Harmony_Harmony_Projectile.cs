﻿using FrontierDevelopments.Shields.Harmony;
using HarmonyLib;
using JetBrains.Annotations;
using VanillaWeaponsExpandedLaser;
using Verse;

namespace FrontierDevelopments.Shields.VweLaserModule.Harmony
{
    // Token: 0x02000003 RID: 3
    public class Harmony_Harmony_Projectile
    {
        // Token: 0x02000004 RID: 4
        [HarmonyPatch(typeof(Harmony_Projectile), "ShouldImpact")]
        [UsedImplicitly]
        private static class Patch_ShouldImpact
        {
            // Token: 0x06000003 RID: 3 RVA: 0x00002080 File Offset: 0x00000280
            [HarmonyPostfix]
            private static bool HandleLaser(bool __result, Projectile projectile)
            {
                if (__result || projectile is not LaserBeam)
                {
                    return __result;
                }

                Log.Message("laser impact!");
                return true;
            }
        }
    }
}