﻿using System.Reflection;
using Verse;

namespace FrontierDevelopments.Shields.VweLaserModule
{
    // Token: 0x02000002 RID: 2
    public class Module : Mod
    {
        // Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
        public Module(ModContentPack content) : base(content)
        {
            Log.Message("loading");
            new HarmonyLib.Harmony("FrontierDevelopments.Shields.VweLaser").PatchAll(Assembly.GetExecutingAssembly());
        }
    }
}